package com.hfad.dormandmealplan_lc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * This app calculates the cost of a user's room and board
 * based on whatever dorm and meal plan they select
 * @author - Luke Cossman
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Override onCreate function for running of app
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get handles for xml view objects
        TextView txtOutput = findViewById(R.id.txt_output);
        Button btnCalculate = findViewById(R.id.btn_calculate);
        Spinner spnMeals = findViewById(R.id.spn_meal);
        Spinner spnDorms = findViewById(R.id.spn_dorm);

        //Create functionality for calculate button
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                String meal = spnMeals.getSelectedItem().toString(); //User's meal plan choice
                String dorm = spnDorms.getSelectedItem().toString(); //User's dorm choice
                int total = 0; //Total cost
                String msg; //Message to be printed

                //Determine which meal plan the user selected and add its cost to the total
                switch (meal) {
                    case "7 per week - $600":
                        total = 600;
                        break;
                    case "14 per week - $1100":
                        total = 1100;
                        break;
                    case "Unlimited - $1800":
                        total = 1800;
                        break;
                }

                //Determine which dorm the user selected and add its cost to the total
                switch (dorm) {
                    case "Allen Hall - $1800":
                        total += 1800;
                        break;
                    case "Pike Hall - $2200":
                        total += 2200;
                        break;
                    case "Farthing Hall - $2800":
                        total += 2800;
                        break;
                    case "University Suites - $3000":
                        total += 3000;
                        break;
                }

                //Print out the user's total bill
                msg = "$" + total;
                txtOutput.setText(msg);

            }
        });


    }
}